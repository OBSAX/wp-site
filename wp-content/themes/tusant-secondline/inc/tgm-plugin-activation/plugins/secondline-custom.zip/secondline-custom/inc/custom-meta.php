<?php

function secondline_get_term_options( $field ) {
	$args = $field->args( 'get_terms_args' );
	$args = is_array( $args ) ? $args : array();

	$args = wp_parse_args( $args, array( 'taxonomy' => 'category' ) );

	$taxonomy = $args['taxonomy'];

	$terms = (array) cmb2_utils()->wp_at_least( '4.5.0' )
		? get_terms( $args )
		: get_terms( $taxonomy, $args );

	// Initate an empty array
	$term_options = array();
	if ( ! empty( $terms ) ) {
		foreach ( $terms as $term ) {
			$term_options[ $term->term_id ] = $term->name;
		}
	}

	return $term_options;
}


function secondline_themes_addons_show_categories_ssp(){
	$terms = get_terms( array(
		'taxonomy' => 'series',
		'hide_empty' => true,
	));

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
	foreach ( $terms as $term ) {
		$options[ $term->slug ] = $term->name;
	}
	return $options;
	}
}




add_action( 'cmb2_admin_init', 'secondline_themes_page_meta_box' );
function secondline_themes_page_meta_box() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_themes_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_themes_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_page_settings',
		'title'         => esc_html__('Page Settings', 'secondline-custom-tusant'),
		'object_types'  => array( 'page' ), // Post type,
	) );
	
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Sub-title', 'secondline-custom-tusant'),
		'id'         => $prefix . 'sub_title',
		'type'       => 'text',
	) );

	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Sidebar Display', 'secondline-custom-tusant'),
		'id'         => $prefix . 'page_sidebar',
		'type'       => 'select',
		'options'     => array(
			'hidden-sidebar'   => esc_html__( 'Hide Sidebar', 'secondline-custom-tusant' ),
			'right-sidebar'    => esc_html__( 'Right', 'secondline-custom-tusant' ),
			'left-sidebar'    => esc_html__( 'Left', 'secondline-custom-tusant' ),
		),
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('Title Area Background Image', 'secondline-custom-tusant'),
		'id'         => $prefix . 'header_image',
		'type'         => 'file',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Title Area', 'secondline-custom-tusant'),
		'id'         => $prefix . 'disable_page_title',
		'type'       => 'checkbox',
	) );
	
}



add_action( 'cmb2_admin_init', 'secondline_themes_page_header_meta_box' );
function secondline_themes_page_header_meta_box() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_themes_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_themes_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_page_header',
		'title'         => esc_html__('Display Settings', 'secondline-custom-tusant'),
		'object_types'  => array( 'page' ), // Post type,
	) );
		
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Header', 'secondline-custom-tusant'),
		'id'         => $prefix . 'header_disabled',
		'type'       => 'checkbox',
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Footer', 'secondline-custom-tusant'),
		'id'         => $prefix . 'disable_footer_per_page',
		'type'       => 'checkbox',
	) );


	
}



add_action( 'cmb2_admin_init', 'secondline_themes_index_post_meta_box' );
function secondline_themes_index_post_meta_box() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_themes_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_themes_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_post',
		'title'         => esc_html__('Post Settings', 'secondline-custom-tusant'),
		'object_types'  => array( 'post', 'podcast', 'episode', 'product', 'download' ), // Post type
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Featured Image on Post', 'secondline-custom-tusant'),
		'id'         => $prefix . 'disable_img',
		'type'       => 'checkbox',
	) );		
	
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('Image Gallery', 'secondline-custom-tusant'),
		'id'         => $prefix . 'gallery',
		'type'         => 'file_list',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
	) );	
    
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('Title Area Background Image', 'secondline-custom-tusant'),
		'id'         => $prefix . 'header_image',
		'type'         => 'file',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
	) );    	
	
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('External Embed Code (SoundCloud, Libsyn, MixCloud etc.) ', 'secondline-custom-tusant'),
		'id'         => $prefix . 'external_embed',
		'type'       => 'textarea_code',
		'options' => array( 'disable_codemirror' => true ),
	) );	
	
		
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('Parent Show Post', 'secondline-custom-tusant'),
		'desc'           => 'Choose the main Show post that this episode belongs to. This would change the type of the header to display the show data above the actual episode.',
		'id'         => $prefix . 'parent_show_post',
		'type'       => 'select',
		'show_option_none' => true,
		'default'          => 'custom',
		'options_cb'          => 'secondline_get_your_post_type_post_options',
	) );		

}


add_action( 'cmb2_admin_init', 'secondline_themes_index_show_meta_box' );
function secondline_themes_index_show_meta_box() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_themes_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_themes_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_show',
		'title'         => esc_html__('Show Settings', 'secondline-custom-tusant'),
		'object_types'  => array( 'secondline_shows' ), // Post type
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Featured Image on Header', 'secondline-custom-tusant'),
		'desc'           => 'Enable/Disable the featured image that shows up on the single show page inside the header.',
		'id'         => $prefix . 'disable_img',
		'default'	 => false,
		'type'       => 'checkbox',
	) );		
    
	$secondline_themes_cmb_demo->add_field( array(
		'name' => esc_html__('Title Area Background Image', 'secondline-custom-tusant'),
		'desc'           => 'Insert the background image here. This would show up on the single show page as a background of the header.',
		'id'         => $prefix . 'header_image',
		'type'         => 'file',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
	) );    	
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Header Show Description', 'secondline-custom-tusant'),
		'desc'           => 'Insert a short description here. This would show up on the single show page inside the header.',
		'id'         => $prefix . 'show_short_desc',
		'type'       => 'textarea_small',
	) );		
		
	if ( function_exists( 'ssp_get_upload_directory' ) ) {
		
		$secondline_themes_cmb_demo->add_field( array(
			'name'           => 'Podcast Series/Category To Display',
			'desc'           => 'Select the Podcast series/category that should be linked with this show. This would automatically display all related episodes inside the show page.',
			'id'             => $prefix . 'show_category_selection',
			'type'           => 'multicheck_inline',
			'options_cb'     => 'secondline_themes_addons_show_categories_ssp',
			'get_terms_args' => array(
				'taxonomy'   => 'series',
				'hide_empty' => false,
				'post_type'	 => 'podcast',
			),
			'select_all_button' => false,
		) );			
		
		
	} else {
	
		$secondline_themes_cmb_demo->add_field( array(
			'name'           => 'Post Category To Display',
			'desc'           => 'Select the post category (or categories) that should be linked with this show. This would automatically display all related episodes inside the show page.',
			'id'             => $prefix . 'show_category_selection',
			'type'           => 'multicheck_inline',
			'options_cb'     => 'secondline_get_term_options',
			'get_terms_args' => array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
				'post_type'	 => 'post',
			),
			'select_all_button' => false,
		) );	
	}
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Episode List on Show Page?', 'secondline-custom-tusant'),
		'desc'           => 'Enable/Disable the automatic list of episodes that appears on the single show page.',
		'id'         => $prefix . 'disable_list',
		'default'	 => false,
		'type'       => 'checkbox',
	) );		
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Show Hosts', 'secondline-custom-tusant'),
		'desc'           => 'Insert the name (names) of the show host (hosts) here, example: Jon Doe & Linda Doe',
		'id'         => $prefix . 'show_hosts',
		'type'       => 'text',
	) );		
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Show Hosts Avatar', 'secondline-custom-tusant'),
		'desc'           => 'Insert one image of the show hosts. (Recommended dimensions of 150x150 px)',
		'id'         => $prefix . 'show_hosts_img',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
		'type'       => 'file',
	) );	

	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Show Website Link', 'secondline-custom-tusant'),
		'desc'           => 'Insert the URL of the shows separate website. (Optional)',
		'id'         => $prefix . 'show_website',
		'type'       => 'text_url',
	) );		
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Show RSS Feed Link', 'secondline-custom-tusant'),
		'desc'           => 'Add an RSS link to your website header to comply with Google Podcasts (Optional, recommended)',
		'id'         => $prefix . 'show_rss_feed',
		'type'       => 'text_url',
	) );		

}




add_action( 'cmb2_admin_init', 'secondline_themes_index_show_social_meta_box' );
function secondline_themes_index_show_social_meta_box() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_themes_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_themes_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_show_subscribe',
		'title'         => esc_html__('Subscribe & Social Links', 'secondline-custom-tusant'),
		'object_types'  => array( 'secondline_shows' ), // Post type
	) );
	
	$secondline_themes_cmb_demo->add_field( array(
		'name'       => esc_html__('Disable Subscribe Button?', 'secondline-custom-tusant'),
		'desc'           => 'Enable/Disable the subscribe button',
		'id'         => $prefix . 'show_subscribe_button',
		'default'	 => false,
		'type'       => 'checkbox',
	) );	
	
	
	$slt_subscribe_group_field_id = $secondline_themes_cmb_demo->add_field( array(
		'id'          => $prefix . 'repeat_subscribe',
		'type'        => 'group',
		'description' => esc_attr__( 'Add Subscribe Button Links', 'secondline-custom-tusant' ),
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_attr__( 'Subscribe Link {#}', 'secondline-custom-tusant' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_attr__( 'Add Another Link', 'secondline-custom-tusant' ),
			'remove_button' => esc_attr__( 'Remove Link', 'secondline-custom-tusant' ),
			'sortable'      => true, // beta
			'closed'		=> true,
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$secondline_themes_cmb_demo->add_group_field( $slt_subscribe_group_field_id, array(
		'name' => 'Subscribe Platform',
		'id'   => $prefix . 'subscribe_platform',
		'type' => 'select',
		'options' => array(
			'Apple-Podcasts' => esc_attr__( 'Apple Podcasts', 'secondline-custom-tusant' ),
			'Google-Podcasts' => esc_attr__( 'Google Podcasts', 'secondline-custom-tusant' ),
			'iTunes' => esc_attr__( 'iTunes', 'secondline-custom-tusant' ),			
			'Google-Play' => esc_attr__( 'Google Play', 'secondline-custom-tusant' ),			
			'Stitcher' => esc_attr__( 'Stitcher', 'secondline-custom-tusant' ),
			'RSS' => esc_attr__( 'RSS', 'secondline-custom-tusant' ),
			'SoundCloud' => esc_attr__( 'SoundCloud', 'secondline-custom-tusant' ),
			'Spotify' => esc_attr__( 'Spotify', 'secondline-custom-tusant' ),
			'TuneIn' => esc_attr__( 'TuneIn', 'secondline-custom-tusant' ),
			'Spreaker' => esc_attr__( 'Spreaker', 'secondline-custom-tusant' ),
			'Miro' => esc_attr__( 'Miro', 'secondline-custom-tusant' ),
			'iHeartRadio' => esc_attr__( 'iHeartRadio', 'secondline-custom-tusant' ),
			'Blubrry' => esc_attr__( 'Blubrry', 'secondline-custom-tusant' ),
			'CastBox' => esc_attr__( 'Castbox', 'secondline-custom-tusant' ),
			'Overcast' => esc_attr__( 'Overcast', 'secondline-custom-tusant' ),
			'PocketCasts' => esc_attr__( 'PocketCasts', 'secondline-custom-tusant' ),
			'Downcast' => esc_attr__( 'Downcast', 'secondline-custom-tusant' ),
			'Deezer' => esc_attr__( 'Deezer', 'secondline-custom-tusant' ),
			'Castro' => esc_attr__( 'Castro', 'secondline-custom-tusant' ),
			'Libsyn' => esc_attr__( 'Libsyn', 'secondline-custom-tusant' ),
			'MixCloud' => esc_attr__( 'MixCloud', 'secondline-custom-tusant' ),
			'Podbean' => esc_attr__( 'Podbean', 'secondline-custom-tusant' ),
			'Amazon-Alexa' => esc_attr__( 'Amazon Alexa', 'secondline-custom-tusant' ),
			'Anchor' => esc_attr__( 'Anchor', 'secondline-custom-tusant' ),
			'Radio-Public' => esc_attr__( 'Radio Public', 'secondline-custom-tusant' ),
			'custom' => esc_attr__( 'Custom Link', 'secondline-custom-tusant' ),
		),		
		//'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );

	$secondline_themes_cmb_demo->add_group_field( $slt_subscribe_group_field_id, array(
		'name' => 'Link',
		'id'   => $prefix . 'subscribe_url',
		'type' => 'text_url',
	) );
	
	$secondline_themes_cmb_demo->add_group_field( $slt_subscribe_group_field_id, array(
		'name' => 'Custom Link - Label',
		'description' => 'Works only for the "Custom" link.',
		'id'   => $prefix . 'custom_link_label',
		'type' => 'text',
	) );
		
	
	
	
	
	$slt_social_group_field_id = $secondline_themes_cmb_demo->add_field( array(
		'id'          => $prefix . 'repeat_social',
		'type'        => 'group',
		'description' => esc_attr__( 'Add Social Icon Links', 'secondline-custom-tusant' ),
		'options'     => array(
			'group_title'   => esc_attr__( 'Social Icon {#}', 'secondline-custom-tusant' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_attr__( 'Add Another Icon', 'secondline-custom-tusant' ),
			'remove_button' => esc_attr__( 'Remove Icon', 'secondline-custom-tusant' ),
			'sortable'      => true, // beta
			'closed'		=> true,
		),
	) );

	// Add new field
	$secondline_themes_cmb_demo->add_group_field( $slt_social_group_field_id, array(
	  'name'        => __( 'Select Icon', 'textdomain' ),
	  'id'   		=> $prefix . 'social_icon',
	  'type'        => 'fontawesome_icon', // This field type
	) );

	$secondline_themes_cmb_demo->add_group_field( $slt_social_group_field_id, array(
		'name' => 'Link',
		'id'   => $prefix . 'social_url',
		'type' => 'text_url',
	) );
		
		
	

		
	

}




add_action( 'cmb2_admin_init', 'secondline_user_meta_box' );
/**
 * Hook in and add a metabox to demonstrate repeatable grouped fields
 */
function secondline_user_meta_box() {
	
	// Start with an underscore to hide fields from custom fields list
	$prefix = 'secondline_';

	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$secondline_cmb_demo = new_cmb2_box( array(
		'id'            => $prefix . 'user_author_info',
		'title'         => esc_html__('Author Settings', 'secondline-custom-tusant'),
		'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta vs post_meta

	) );
	
	$secondline_cmb_demo->add_field( array(
		'name'     => esc_html__( 'Author Information', 'secondline-custom-tusant' ),
		'id'       => $prefix . 'extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );
	

	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Author Sub-headline', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'user_sub_headline',
		'type' => 'text',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Author Website URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'authorurl',
		'type' => 'text_url',
	) );

	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Facebook URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'facebookurl',
		'type' => 'text_url',
	) );

	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Twitter URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'twitterurl',
		'type' => 'text_url',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Dribbble URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'dribbbleurlurl',
		'type' => 'text_url',
	) );


	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Linkedin URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'linkedinurl',
		'type' => 'text_url',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Pinterest URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'pinteresturl',
		'type' => 'text_url',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'MixCloud URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'mixcloudurl',
		'type' => 'text_url',
	) );
	
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Google+ URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'googleplusurl',
		'type' => 'text_url',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Instagram URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'instagramurl',
		'type' => 'text_url',
	) );
	
	

	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Youtube URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'youtubeurl',
		'type' => 'text_url',
	) );
	


	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Vimeo URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'vimeourl',
		'type' => 'text_url',
	) );
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'Soundcloud URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'soundcloudurl',
		'type' => 'text_url',
	) );
	
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'MixCloud URL', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'mixcloudurl',
		'type' => 'text_url',
	) );

	
	
	
	$secondline_cmb_demo->add_field( array(
		'name' => esc_html__( 'E-mail Address', 'secondline-custom-tusant' ),
		'desc' => esc_html__( 'Leave blank to hide this field', 'secondline-custom-tusant' ),
		'id'   => $prefix . 'emailmailto',
		'type' => 'text',
	) );
	

}




