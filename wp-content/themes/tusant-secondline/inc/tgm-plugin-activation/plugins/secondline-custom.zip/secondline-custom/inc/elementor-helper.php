<?php
namespace Elementor;


//
// Commented for now, as we use the "Basic" category
//
/* function secondline_theme_elements_elementor_init($elements_manager){
	$elements_manager->add_category(
		'secondline-themes-tusant',
		[
			'title' => __( 'Theme Addons', 'plugin-name' ),
			'icon' => 'fa fa-plug',
		]
	);
}
add_action('elementor/elements/categories_registered','Elementor\secondline_theme_elements_elementor_init'); */






//Query List
function secondline_elements_post_lists(){
	global $post;
	$sltposts = new \WP_Query( array( 'post_type' => 'post', 'posts_per_page' => '99999', ) );	

	if ( $sltposts->have_posts() ) {
		$options = array();
		$options['none'] = '-';
		while ( $sltposts->have_posts() ) {
			$sltposts->the_post();
			$options[get_the_id()] = get_the_title();
		}		

		wp_reset_postdata();
		
	} else {
		// no posts found
	}	


	return $options;	
	
}


//Query List
function secondline_elements_show_grid(){
	global $post;
	$sltposts = new \WP_Query( array( 'post_type' => 'secondline_shows', 'posts_per_page' => '99999', ) );	

	if ( $sltposts->have_posts() ) {
		$options = array();
		$options['none'] = '-';
		while ( $sltposts->have_posts() ) {
			$sltposts->the_post();
			$options[get_the_id()] = get_the_title();
		}		

		wp_reset_postdata();
		
	} else {
		// no posts found
	}	


	return $options;	
	
}

//Query Post Types
function secondline_themes_post_type_control(){
	
	$secondline_cpts = get_post_types( array( 'public'   => true, 'show_in_nav_menus' => true ) );
	$secondline_exclude_cpts = array( 'elementor_library', 'attachment', 'product', 'page' );
	
	
	foreach ( $secondline_exclude_cpts as $exclude_cpt ) {
		unset($secondline_cpts[$exclude_cpt]);
	}
	

	$post_types = array_merge($secondline_cpts);
	return $post_types;
}
